
public class Person {
	public String name=null;
	public int age=0;


	public Person(String name,int age){
		this.name=name;
	}

	public String getname(){
		return this.name;

	}
	public void setname(String name){
		this.name=name;
	}

}
