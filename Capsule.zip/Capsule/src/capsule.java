
public class capsule {

	public static void main(String[] args) {


	Person taro=new Person("山田太朗",20);
	System.out.println(taro.name);

	}

}
