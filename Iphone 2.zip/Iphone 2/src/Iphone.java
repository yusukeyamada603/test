
public class Iphone {

	public static void main(String[] args) {
		// 実装

		Smartphone iphone=new Smartphone();
		iphone.play();
		iphone.stop();
		iphone.next();
		iphone.back();
		iphone.call();
		iphone.mail();
		iphone.photo();
		iphone.internet();

	}

}
