
public interface Mp3player {

	public abstract void play();
	public abstract void stop();
	public abstract void next();
	public abstract void back();

}
