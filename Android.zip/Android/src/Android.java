
public class Android {

	public static void main(String[] args) {
		// 継承

		SmartPhone android=new SmartPhone();
		android.play();
		android.stop();
		android.next();
		android.back();
		android.call();
		android.mail();
		android.photo();
		android.internet();
	}


}
