
public class ABC {


		// TODO 自動生成されたメソッド・スタブ
public String name=null;
   public int age=0;
   public ABC(){}

   public ABC(String name,int age){
	   this.name=name;
	   this.age=age;
	}
   public ABC(String name){
	   this.name=name;
	   this.age=0;

   }
   public ABC(int age){
	   this.name="名前なし";
	   this.age=age;}

   public ABC(int age,String name){
	   this.name=name;
	   this.age=age;}




}
