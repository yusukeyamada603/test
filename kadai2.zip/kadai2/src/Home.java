
public class Home {

	public static void main(String[] args) {
		// コンスタンス化課題　HOMEクラスと繋がっている
		ABC taro=new ABC();
        taro.name="太郎";
        taro.age=18;
        System.out.println(taro.name);
        System.out.println(taro.age);

        ABC jiro=new ABC("jiro",20);
        System.out.println(jiro.name);
        System.out.println(jiro.age);


        ABC saburo=new ABC("saburo");
        System.out.println(saburo.name);
        System.out.println(saburo.age);


        ABC a=new ABC("名前なし",20);
        System.out.println(a.name);
        System.out.println(a.age);


        ABC hanako=new ABC("hanako",17);
        System.out.println(hanako.name);
        System.out.println(hanako.age);

	}

}
