
public class age {

	public int a;
	public int getage(){
		a=25;
		return a;
		
		
		
	}
}
