
public class address {
	
	public String bbb;
	public String getaddress(){
		bbb="東京";
		return bbb;
	}

}
